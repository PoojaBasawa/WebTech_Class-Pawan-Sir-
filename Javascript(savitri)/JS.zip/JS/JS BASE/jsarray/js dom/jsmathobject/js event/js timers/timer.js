//timers
//when ever we need to delay the execution or we need
//call function again and again we use timers
//we have two types of timers
//1.set timeOut()
//2.setInterval()

//what is the difference between settimeout() and setinterval()
//the main difference between the settimeout() and setinterval()
//is that the settimeout() will execute the callback() only once where as the setInterval()
//keeps on triggering the callback() again and again after give time interval