//all actions in js we call it as events
//to find how many events we have in js
//type in console onclick
//events----->actions
//event is nothing but some activity on the webpage
//event consist of two things eventlistener and
//event handler

//eventlistener:
//it is used t catch the event occured on the element
//ex:onclick,onchange,onkeydown,onmouseover,onmouseout,
//onsubmit

//eventhandler
//it is function or js function function call

<button onclick="f()">Click here</button>

//event is predefined object in js where it contains all
//the information related to click event
