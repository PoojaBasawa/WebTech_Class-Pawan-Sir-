//spread opearator
//...<object_name>
//or
//...<array name>
//it is used to copy properties of one object into another object
//and it is used to copy elements of one array to another array

//example applying spread operator object
// var obj1={
//     name:'sumathi',
//     age:21

// }
// console.log(obj1)
// var obj2={
//     ...obj1,
//     id:3,
//     gender:'male'
// }
// console.log(obj2)
// var obj3={
//     ...obj2,
//     loaction:"mumbai"
// }
// console.log(obj3)


//applying spread operator for array

// var arr1=[1,2,3,4,5]
// console.log(arr1)
// var arr2=[...arr1,6,7,8,9,10]
// console.log(arr2)//spread opearator
//...<object_name>
//or
//...<array name>
//it is used to copy properties of one object into another object
//and it is used to copy elements of one array to another array

//example applying spread operator object
// var obj1={
//     name:'sumathi',
//     age:21

// }
// console.log(obj1)
// var obj2={
//     ...obj1,
//     id:3,
//     gender:'male'
// }
// console.log(obj2)
// var obj3={
//     ...obj2,
//     loaction:"mumbai"
// }
// console.log(obj3)


//applying spread operator for array

// var arr1=[1,2,3,4,5]
// console.log(arr1)
// var arr2=[...arr1,6,7,8,9,10]
// console.log(arr2)